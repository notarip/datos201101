/*
 * LibrosEliminados.h
 *
 *  Created on: 06/04/2011
 *      Author: hernan
 */

#ifndef LIBROSELIMINADOS_H_
#define LIBROSELIMINADOS_H_

class LibrosEliminados {
public:
	LibrosEliminados();
	unsigned long obtenerDisponible(unsigned long tamanio);

	virtual ~LibrosEliminados();
};

#endif /* LIBROSELIMINADOS_H_ */
