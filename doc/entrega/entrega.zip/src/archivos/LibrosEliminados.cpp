/*
 * LibrosEliminados.cpp
 *
 *  Created on: 06/04/2011
 *      Author: hernan
 */

#include "LibrosEliminados.h"

LibrosEliminados::LibrosEliminados() {
	// TODO Auto-generated constructor stub

}

LibrosEliminados::~LibrosEliminados() {
	// TODO Auto-generated destructor stub
}
