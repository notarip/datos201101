/*
 * PruebaArbolMasAlfabetico.cpp
 *
 *  Created on: 22/04/2011
 *      Author: rjc
 */

#include "../ArbolB+/ArbolBMasAlfabetico.h"
#include "string.h"

using namespace std;

int main22(){
	string unPath = "ArbolBMas";

	ArbolBMasAlfabetico* miArbol = new ArbolBMasAlfabetico(unPath,120);

	cout << "insercion pedro" << endl;
	resultadoOperacion unResultado = miArbol->insertar("pedro",0);
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "insercion gabriel" << endl;
	unResultado = miArbol->insertar("gabriel",0);
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "insercion juan" << endl;
	unResultado = miArbol->insertar("juan",0);
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "insercion agustina" << endl;
	unResultado = miArbol->insertar("agustina",0);
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "insercion gaston" << endl;
	unResultado = miArbol->insertar("gaston",0);
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "insercion maria" << endl;
	unResultado = miArbol->insertar("maria",0);
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "insercion mercedes" << endl;
	unResultado = miArbol->insertar("mercedes",0);
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "insercion pablo" << endl;
	unResultado = miArbol->insertar("pablo",0);
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "insercion maria" << endl;
	unResultado = miArbol->insertar("maria",0);
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "insercion diego" << endl;
	unResultado = miArbol->insertar("diego",0);
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "insercion martin" << endl;
	unResultado = miArbol->insertar("martin",0);
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "insercion lucas" << endl;
	unResultado = miArbol->insertar("lucas",0);
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "insercion juana" << endl;
	unResultado = miArbol->insertar("juana",0);
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "insercion jose" << endl;
	unResultado = miArbol->insertar("jose",0);
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "insercion victoria" << endl;
	unResultado = miArbol->insertar("victoria",0);
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "insercion amalia" << endl;
	unResultado = miArbol->insertar("amalia",0);
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "insercion viviana" << endl;
	unResultado = miArbol->insertar("viviana",0);
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "insercion facundo" << endl;
	unResultado = miArbol->insertar("facundo",0);
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "insercion horacio" << endl;
	unResultado = miArbol->insertar("horacio",0);
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "insercion pedro" << endl;
	unResultado = miArbol->insertar("pedro",0);
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "insercion mariela" << endl;
	unResultado = miArbol->insertar("mariela",0);
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "insercion lucia" << endl;
	unResultado = miArbol->insertar("lucia",0);
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "insercion santiago" << endl;
	unResultado = miArbol->insertar("santiago",0);
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "insercion natalia" << endl;
	unResultado = miArbol->insertar("natalia",0);
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "insercion julia" << endl;
	unResultado = miArbol->insertar("julia",0);
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "insercion julieta" << endl;
	unResultado = miArbol->insertar("julieta",0);
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "insercion juliana" << endl;
	unResultado = miArbol->insertar("juliana",0);
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "insercion julio" << endl;
	unResultado = miArbol->insertar("julio",0);
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "insercion julian" << endl;
	unResultado = miArbol->insertar("julian",0);
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "insercion mariano" << endl;
	unResultado = miArbol->insertar("mariano",0);
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "insercion mara" << endl;
	unResultado = miArbol->insertar("mara",0);
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "insercion marcelo" << endl;
	unResultado = miArbol->insertar("marcelo",0);
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "insercion marcela" << endl;
	unResultado = miArbol->insertar("marcela",0);
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "eliminacion julian" << endl;
	unResultado= miArbol->eliminar("julian");
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "eliminacion gabriel" << endl;
	unResultado= miArbol->eliminar("gabriel");
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "eliminacion agustina" << endl;
	unResultado= miArbol->eliminar("agustina");
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "eliminacion amalia" << endl;
	unResultado= miArbol->eliminar("amalia");
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "eliminacion anastacio" << endl;
	unResultado= miArbol->eliminar("anastacio");
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "eliminacion horacio" << endl;
	unResultado= miArbol->eliminar("horacio");
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "eliminacion jose" << endl;
	unResultado= miArbol->eliminar("jose");
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "eliminacion julieta" << endl;
	unResultado= miArbol->eliminar("julieta");
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "eliminacion lucas" << endl;
	unResultado= miArbol->eliminar("lucas");
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "insercion juliana" << endl;
	unResultado = miArbol->insertar("juliana",0);
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "eliminacion julio" << endl;
	unResultado= miArbol->eliminar("julio");
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	cout << "eliminacion amalia" << endl;
	unResultado= miArbol->eliminar("amalia");
	cout << unResultado.getDescripcion() << endl << endl;
	miArbol->exportar("prueba");

	resultadoOperacion resultadoOp(OK);

	cout << "busqueda santiago" << endl;
	Registro* regEncontrado= miArbol->buscarRegistro("santiago", &resultadoOp);
	cout<<resultadoOp.getDescripcion()<<endl;
	cout<<"encontre: "<<regEncontrado->getString()<<endl<<endl;

	cout << "busqueda marcelo" << endl;
	regEncontrado= miArbol->buscarRegistro("marcelo", &resultadoOp);
	cout<<resultadoOp.getDescripcion()<<endl;
	cout<<"encontre: "<<regEncontrado->getString()<<endl<<endl;

	cout << "busqueda zoe" << endl;
	regEncontrado= miArbol->buscarRegistro("zoe", &resultadoOp);
	cout<<resultadoOp.getDescripcion()<<endl;
	cout<<"encontre: "<<regEncontrado->getString()<<endl<<endl;

	regEncontrado= miArbol->buscarRegistro("diego",&resultadoOp);

	cout << "recuperacion secuencial" <<endl;

	while (regEncontrado!=NULL){
		cout<<regEncontrado->getString()<<"|";
		regEncontrado= miArbol->siguiente();
	}

	cout <<endl<<endl <<"FIN DE PRUEBA ALFABETICO CAMPEON" << endl;

	delete miArbol;
	return 0;
}
